## Module <om_hr_payroll_account>

#### 09.12.2023
#### Version 18.0.1.0.0
##### ADD
- initial release
